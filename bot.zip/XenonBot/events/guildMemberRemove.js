module.exports = member => {
  const guild = member.guild;
  guild.channels.get(`422831741556752387`).send(member.user + `La revedere, sper sa te mai vad :sob:`);
};
