const Discord = require ("discord.js")
const client = new Discord.Client();
const prefix = "%"
client.on('message', message =>{
  let args = message.content.split(" ").slice(1);

//SAY
  if (message.content.startsWith(prefix + "say")) {
    message.delete()
    const embed =  new Discord.RichEmbed()
    .setDescription(args.join(" "))
    .setColor(0xff0000)
    message.channel.sendEmbed(embed);
  }

//SERVERINFO
if (message.content.startsWith(prefix + 'serverinfo')) {
  const embed = new Discord.RichEmbed()
  embed.addField('Members', message.guild.memberCount, true)
  embed.addField('Name', message.guild.name, true)
  embed.addField('Region', message.guild.region, true)
  embed.addField('Owner', message.guild.owner, true)
  embed.addField('ID', message.guild.id, true)
  embed.setColor(`ff0000`)
  embed.setThumbnail(message.guild.iconURL)
  message.channel.sendEmbed(embed)
}

});
client.login(`NDIyODIxNzE3OTk2NjAxMzQ0.DYha8Q.E55SnyPI6r-j1wsGMFhOfXEzakg`);
