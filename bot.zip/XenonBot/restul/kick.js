const {RichEmbed} = require('discord.js');
const {caseNumber} = require('../util/caseNumber.js');
const {parseUser} = require('../util/parseUser.js');
const settings = require('../settings.json');
const Discord = require('discord.js');
exports.run = async (client, message, args) => {
  const user = message.mentions.users.first();
  parseUser(message, user);
  const modlog = client.channels.find('name', 'mod-log');
  const caseNum = await caseNumber(client, modlog);
  if (!modlog) return message.reply('nu pot sa gasesc o camera numita mod-log');
  if (message.mentions.users.size < 1) return message.reply('Trebuie sa mentionezi o persoana').catch(console.error);
  if (!message.guild.member(user).kickable) return message.reply('Nu pot sa ii dau kick acestei persoane !');
    message.guild.member(user).kick();
  // message.guild.member(user).kick();

const reason = args.slice(1).join(' ');
  //const reason = args.splice(1, args.length).join(' ') || `Awaiting moderator's input. Use ${settings.prefix}reason ${caseNum} <reason>.`;
  const embed = new RichEmbed()
  .setColor('540547')
  .setTimestamp()
  .setDescription(`**Action:** Kick\n**Target:** ${user.tag}\n**Moderator:** ${message.author.tag}\n**Reason:** ${reason}`)
  .setFooter(`Case ${caseNum}`);
  message.channel.send(`${user.username} a primit kick!`)
  return client.channels.get(modlog.id).send({embed});
};

exports.conf = {
  aliases: [],
  permLevel: 2
};

// exports.help = {
// name: 'kick',
  // description: 'Dai afara persoana mentionata',
  // usage: 'kick <mention> <motiv>'
// };
