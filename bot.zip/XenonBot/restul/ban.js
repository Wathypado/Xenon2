const {RichEmbed} = require('discord.js');
const {caseNumber} = require('../util/caseNumber.js');
const {parseUser} = require('../util/parseUser.js');
const settings = require('../settings.json');
const Discord = require('discord.js');
const embed = new RichEmbed()
exports.run = async (client, message, args) => {
  embed.setColor(0x00AE86);
  const user = message.mentions.users.first();
  parseUser(message, user);
  if (message.mentions.members.size === 0) return message.channel.send('Trebuie sa mentionezi pe cineva');//.catch(console.error);
  if (!message.guild.member(user).bannable) return message.channel.send('Nu pot da ban acestui membru');
  message.guild.ban(user, 2);

const reason = args.slice(1).join(' ');
  embed.setTimestamp()
  embed.setDescription(`**Action:** Ban\n**Target:** ${user.tag}\n**Moderator:** ${message.author.tag}\n**Reason:** ${reason}`)
  embed.setFooter(`Case ${caseNum}`);
  message.channel.send(`${user.username} a primit ban!`)
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 2
};

//exports.help = {
  // name: 'ban',
  // description: 'Baneaza persoana mentionata',
  // usage: '$ban <mention> <motiv>'
// };
