const {RichEmbed} = require('discord.js');
exports.run = (client, message, args) => {
  const reason = args.slice(1).join(' ');
  client.unbanReason = reason;
  client.unbanAuth = message.author;
  const user = args[0];
  const modlog = client.channels.find('name', 'mod-log');
  if (!modlog) return message.reply('Nu gasesc o camera numita mod-log');
  if (reason.length < 1) return message.reply('Trebuie sa pui un modiv sa ii dai unban.');
  if (!user) return message.reply('Trebuie sa pui un user sau un id').catch(console.error);
  message.guild.unban(user);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 2
};

//exports.help = {
//  name: 'unban',
//  description: 'Dai unban unei persoane',
//  usage: '$unban <id> <motiv>'
//};
